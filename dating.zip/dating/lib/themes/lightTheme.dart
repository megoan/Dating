import 'package:flutter/material.dart';

class LightTheme {
  static ThemeData getTheme() {
   
    return new ThemeData(
      brightness: Brightness.light,
      primaryColor: Colors.purple,
      accentColor: Colors.lightBlueAccent,
    );
  }
}
